package com.multibtn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MultiBtnSrv extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter pw = response.getWriter();
		
		int fval = Integer.parseInt(request.getParameter("fval"));
		int sval = Integer.parseInt(request.getParameter("sval"));
		
		String btnval= request.getParameter("button");
		
		switch(btnval){
		
		case "ADD":
			pw.println("sum is"+(fval+sval));
			break;
		case "SUB":
			pw.println("sum is"+(fval - sval));
			break;
		case "MUL":
			pw.println("sum is"+(fval * sval));
			break;
		case "DIV":
			pw.println("sum is"+(fval/sval));	
			break;
		default:
			pw.println("Invalid");
			
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
